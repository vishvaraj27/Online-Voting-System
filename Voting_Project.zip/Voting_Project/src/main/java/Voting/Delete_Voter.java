package Voting;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/DeleteVoter")
public class Delete_Voter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("deletvoter");
		

		RequestDispatcher dispatcher = null;
		Connection con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingmachine?useSSL=false", "root", "root");
			PreparedStatement pst = con.prepareStatement("DELETE FROM user_registration WHERE id = '19' ;");

			pst.setString(1, id);
			
		
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				//request.setAttribute("msgbox", "successfull");
				System.out.println("Your are successfully deleted");
				//dispatcher = request.getRequestDispatcher("Candidate_Home.jsp");
			} else {
				//HttpSession httpSession=request.getSession();
				//httpSession.setAttribute("messagefail", "Invalid Id & Password ");
				System.out.println("Your are not deleted");
				//dispatcher = request.getRequestDispatcher("Candidate_Login.jsp");
			}
		//	dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.print(e);
		}
	}

}
