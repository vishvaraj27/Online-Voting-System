package Voting;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/Adminlogin")
public class Admin_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String Aname = request.getParameter("username");
		String Apwd = request.getParameter("password");

		HttpSession session = request.getSession();
		RequestDispatcher dispatcher = null;
		Connection con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingmachine?useSSL=false", "root", "root");
			PreparedStatement pst = con.prepareStatement("select * from admin_login where Aname=? and Apwd=?");

			pst.setString(1, Aname);
			pst.setString(2, Apwd);
		
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				request.setAttribute("msgbox", "successfull");
				System.out.println("Your are successfully login");
				dispatcher = request.getRequestDispatcher("Admin_Homepage.jsp");
			} else {
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("messagefail", "Invalid Id & Password");
				System.out.println("Your id pass not match");
				dispatcher = request.getRequestDispatcher("Admin_Login.jsp");
			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.print(e);
		}
	}

}
