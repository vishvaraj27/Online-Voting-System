package Voting;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/contactus")
public class Contactus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		

		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String contact = request.getParameter("contact");
		String msg = request.getParameter("message");

		RequestDispatcher dispatcher = null;

		Connection con = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/votingmachine?allowPublicKeyRetrieval=true&useSSL=false", "root", "root");
			PreparedStatement pst = con.prepareStatement(
					"insert into contactus(name,email,contact,msg) values(?,?,?,?)");

			pst.setString(1, name);
			pst.setString(2, email);
			pst.setString(3, contact);
			pst.setString(4, msg);
		
			int i = pst.executeUpdate();
			
			if (i > 0) {
				System.out.println("Your are successfully registerd");
				dispatcher =request.getRequestDispatcher("index.jsp");
			} else {
				System.out.println("registerd failed");
	
			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}