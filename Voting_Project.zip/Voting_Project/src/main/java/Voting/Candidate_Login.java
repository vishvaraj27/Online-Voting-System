package Voting;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/CandidateLogin")
public class Candidate_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String c_email = request.getParameter("name");
		String c_pwd = request.getParameter("password");

		RequestDispatcher dispatcher = null;
		Connection con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingmachine?useSSL=false", "root", "root");
			PreparedStatement pst = con.prepareStatement("select * from candidate_registration where c_email=? and c_pwd=?");

			pst.setString(1, c_email);
			pst.setString(2, c_pwd);
		
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				request.setAttribute("msgbox", "successfull");
				System.out.println("Your are successfully login");
				dispatcher = request.getRequestDispatcher("Candidate_Home.jsp");
			} else {
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("messagefail", "Invalid Id & Password ");
				System.out.println("Your id pass not match");
				dispatcher = request.getRequestDispatcher("Candidate_Login.jsp");
			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.print(e);
		}
	}

}
