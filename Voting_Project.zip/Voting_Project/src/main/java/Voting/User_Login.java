package Voting;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@WebServlet("/login")
public class User_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		 String uemail = request.getParameter("name");
			String upwd = request.getParameter("password");
			
			String name = request.getParameter("name");
		
//			RequestDispatcher dispatcher = null;
			Connection con = null;
			
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingmachine?allowPublicKeyRetrieval=true&useSSL=false", "root", "root");
				PreparedStatement pst = con.prepareStatement("select * from user_registration where uemail=? and upwd=?");//or umobile=?

				pst.setString(1, uemail);
				pst.setString(2, upwd);
				
				PrintWriter out = response.getWriter();
				out.print(uemail);	
				out.print(upwd);
				ResultSet rs = pst.executeQuery();

				if (rs.next()) {
					
					HttpSession session=request.getSession();
					session.setAttribute("uemail",name);	
					//otp send start
					RequestDispatcher dispatcher = null;
					int otpvalue = 0;
					HttpSession mySession = request.getSession();
					
					if(uemail!=null || !uemail.equals("")) {
						// sending otp
						Random rand = new Random();
						otpvalue = rand.nextInt(1255650);

						String to = uemail;// change accordingly
						// Get the session object
						Properties props = new Properties();
						props.put("mail.smtp.host", "smtp.gmail.com");
						props.put("mail.smtp.socketFactory.port", "465");
						props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
						props.put("mail.smtp.auth", "true");
						props.put("mail.smtp.port", "465");
						Session sessions = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
							protected PasswordAuthentication getPasswordAuthentication() {
								return new PasswordAuthentication("vishvarajrana987@gmail.com", "zbkxubcytpxabiil");// Put your email
																												
																												
							}
						});
						// compose message
						try {
							MimeMessage message = new MimeMessage(sessions);
							message.setFrom(new InternetAddress(uemail));// change accordingly
							message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
							message.setSubject("Voting System");
							message.setText("Your OTP is: " + otpvalue + " Do Not Share OTP with Anyone");
							// send message
							Transport.send(message);
							System.out.println("message sent successfully");
						}

						catch (MessagingException e) {
							throw new RuntimeException(e);
						}

					}
					
					dispatcher = request.getRequestDispatcher("User_Home.jsp");//EnterOtp_Voting
					
					request.setAttribute("message","OTP is sent to your email id");
					//request.setAttribute("connection", con);
					mySession.setAttribute("otp",otpvalue); 
					mySession.setAttribute("name",uemail); 
					dispatcher.forward(request, response);
					//otp stop
					//request.setAttribute("status", "success");
					
					request.setAttribute("msgbox", "successfull");
					System.out.println("Your are successfully login");
			
//					dispatcher = request.getRequestDispatcher("User_Home.jsp");//PartySelection.jsp  Mail_Voting.jsp
				} else {
					HttpSession httpSession=request.getSession();
					httpSession.setAttribute("messagefail", "Invalid Id & Password");
					response.sendRedirect("User_login.jsp");
				
					System.out.println("Your id pass not match");
				}
			} catch (Exception e) {
				System.out.print(e);
			}
		}}
	