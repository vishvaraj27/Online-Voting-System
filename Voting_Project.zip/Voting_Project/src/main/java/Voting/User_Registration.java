package Voting;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/register")
public class User_Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		

		String uname = request.getParameter("name");
		String uage = request.getParameter("age");
		String umobile = request.getParameter("contact");
		String uvotingcard = request.getParameter("votingcard");
		String uemail = request.getParameter("email");
		String upwd = request.getParameter("pass");

		RequestDispatcher dispatcher = null;

		Connection con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingmachine?useSSL=false", "root", "root");
			PreparedStatement pst1 = con.prepareStatement("select * from user_registration where uvotingcard=?");

			pst1.setString(1, uvotingcard);
			ResultSet rs = pst1.executeQuery();

			if (rs.next()) {
		
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("userregistermsgbox", "Your are Already Registered");
				System.out.println("Your are already registered");
				dispatcher = request.getRequestDispatcher("User_Registration.jsp");
			} else {

			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/votingmachine?allowPublicKeyRetrieval=true&useSSL=false", "root", "root");
			PreparedStatement pst = con.prepareStatement(
					"insert into user_registration(uname,uage,umobile,uvotingcard,uemail,upwd) values(?,?,?,?,?,?)");

			pst.setString(1, uname);
			pst.setString(2, uage);
			pst.setString(3, umobile);
			pst.setString(4, uvotingcard);
			pst.setString(5, uemail);
			pst.setString(6, upwd);

			int i = pst.executeUpdate();
			
			if (i > 0) {
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("message", "Registration Successfull");
		
				System.out.println("Your are successfully registerd");
				dispatcher =request.getRequestDispatcher("User_login.jsp");
			} else {
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("messagefail", "Registration Fail");
				System.out.println("registerd failed");
				dispatcher =request.getRequestDispatcher("User_Registration.jsp");
			}}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}