package Voting;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/savevote")
public class Party_Selection extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String uparty = request.getParameter("c_party");
		System.out.println(uparty);
		RequestDispatcher dispatcher = null;
		Connection con = null;
			
		HttpSession session=request.getSession(false);
		String uname=(String)session.getAttribute("uemail");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingmachine?useSSL=false", "root", "root");
			PreparedStatement pst1 = con.prepareStatement("select * from voting where uname=?");

			pst1.setString(1, uname);
			ResultSet rs = pst1.executeQuery();

			if (rs.next()) {
		
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("alredyvotedmsgbox", "Your Already Voted");
				System.out.println("Your already Voted");
				dispatcher = request.getRequestDispatcher("User_Home.jsp");
			} else {
			//
		//	Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/votingmachine?allowPublickeyRetrieval=true&useSSL=false", "root", "root");
			PreparedStatement pst = con.prepareStatement("insert into voting(uname,uparty,uvoted) values(?,?,1)");

			pst.setString(1, uname);
			pst.setString(2, uparty);
			
			int i = pst.executeUpdate();
			
			if (i>0) {
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("votesuccessfull", "Vote Successfull");
				
				System.out.println("Your are successfully voted");
				dispatcher = request.getRequestDispatcher("User_Home.jsp");
			
			} else {
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("votesuccessfullfail", "Invalid vote");
				
				System.out.println("vote failed");
				dispatcher = request.getRequestDispatcher("User_login.jsp");
			}}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.println(e);
	}
		
	}
}
