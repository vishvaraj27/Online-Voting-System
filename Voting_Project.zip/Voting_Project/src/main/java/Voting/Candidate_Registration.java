package Voting;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/candidateregistation")
@MultipartConfig(maxFileSize = 16177215) 

public class Candidate_Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		

		String c_name = request.getParameter("name");
		String c_party = request.getParameter("partyname");
		String c_age = request.getParameter("age");
		String c_mobile = request.getParameter("contact");
		String c_vcard = request.getParameter("votingcard");
		String c_email = request.getParameter("email");
		String c_pwd = request.getParameter("pass");
	
		InputStream inputStream = null; // input stream of the upload file
        
        // obtains the upload file part in this multipart request
        Part filePart = request.getPart("file");
        if (filePart != null) {
            // prints out some information for debugging
            System.out.println(filePart.getName());
            System.out.println(filePart.getSize());
            System.out.println(filePart.getContentType());
             
            // obtains input stream of the upload file
            inputStream = filePart.getInputStream();
        }
        
		RequestDispatcher dispatcher = null;
		String message = null; 
		Connection con = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/votingmachine?allowPublicKeyRetrieval=true&useSSL=false", "root", "root");
			PreparedStatement pst = con.prepareStatement(
					"insert into candidate_registration(c_name,c_party,c_age,c_mobile,c_vcard,c_email,c_pwd,c_img) values(?,?,?,?,?,?,?,?)");

			pst.setString(1, c_name);
			pst.setString(2, c_party);
			pst.setString(3, c_age);
			pst.setString(4, c_mobile);
			pst.setString(5, c_vcard);
			pst.setString(6, c_email);
			pst.setString(7, c_pwd);
		//	pst.setString(8, c_img);
			if (inputStream != null) {
                // fetches input stream of the upload file for the blob column
				pst.setBlob(8, inputStream);
            }
//			
////			file Upload code start
//			 Part filePart = request.getPart("file");
//			    String fileName = filePart.getSubmittedFileName();
//			    for (Part part : request.getParts()) {
//			      part.write("C:\\Users\\AMAN PATEL 36\\eclipse-workspace\\Voting_Project\\src\\main\\webapp\\CandidateImages\\" + fileName);
//			    }
//			    response.getWriter().print("The file uploaded sucessfully.");
//			  
//			file Upload code stop
			int i = pst.executeUpdate();
			
			if (i > 0) {
				HttpSession httpSession=request.getSession();
				httpSession.setAttribute("message", "Registration Successfull");
				System.out.println("Your are successfully registerd");
				dispatcher =request.getRequestDispatcher("Admin_Homepage.jsp");
			} else {
				System.out.println("registerd failed");
				dispatcher =request.getRequestDispatcher("Candidate_Registration.jsp");
			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}